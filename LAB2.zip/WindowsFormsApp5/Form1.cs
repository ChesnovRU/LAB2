﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }
        bool loaded = false;
        int currentLayer;
        int FrameCout;
        
        DateTime NextFPSUpdate = DateTime.Now.AddSeconds(1);

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string str = dialog.FileName;
                Bin.ReadBIN(str);
                View.SetupView(glControl1.Width, glControl1.Height);
                loaded = true;
                glControl1.Invalidate();
            }
        }

        private void glControl1_Load(object sender, EventArgs e)
        {

        }
        bool needreload = false;

        private void glControl1_Paint(object sender, PaintEventArgs e)
        {
            if (loaded)
            {
                if (radioButton1.Checked)
                {
                    View.DrawQuads(currentLayer);
                    glControl1.SwapBuffers();
                }
                if (radioButton2.Checked)
                {
                    if (needreload)
                    {
                        View.generateTextureimage(currentLayer);
                        View.Load2DTexture();
                        needreload = false;

                    }
                    View.DrawTexture();
                    glControl1.SwapBuffers();
                }
                if (radioButton3.Checked)
                {
                    View.DrawQuadStrip(currentLayer);
                    glControl1.SwapBuffers();
                }
                

                
                
                
               
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            currentLayer = trackBar1.Value;
            needreload = true;
        }
        void Application_Idle(object sender, EventArgs e)
        {
            while (glControl1.IsIdle)
            {
                displayFPS();
                glControl1.Invalidate();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Application.Idle += Application_Idle;
            trackBar3.Minimum = trackBar2.Value + 1;
        }

         void displayFPS()
        {
            if (DateTime.Now >= NextFPSUpdate)
            {
                this.Text = String.Format("CT Visualizer (fps={0})", FrameCout);
                NextFPSUpdate = DateTime.Now.AddSeconds(1);
                FrameCout = 0;
            }
            FrameCout++;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            //min
            
            View.skrollmin(trackBar2.Value);

            if (radioButton2.Checked)
            {
                View.generateTextureimage(currentLayer);
                View.Load2DTexture();
            }
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            //max
            
            View.skrollmax(trackBar3.Value);

            if (radioButton2.Checked)
            {
                View.generateTextureimage(currentLayer);
                View.Load2DTexture();        
            }

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
