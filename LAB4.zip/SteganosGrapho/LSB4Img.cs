﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SteganosGrapho
{
    class LSB4Img : ProcessImg
    {
        protected ProcessBytes process_bytes;       
        Bitmap image_LSB;
        public override Bitmap get_image_LSB() { return image_LSB; }
        public override Bitmap processImage(Bitmap sourceImage,
        ref BackgroundWorker worker)
        {
            process_bytes = new ProcessBytes();
            Bitmap resultImage = process_bytes.MakeLSB(sourceImage, ref worker);
            image_LSB = resultImage;
            return resultImage;
        }
    }
}
