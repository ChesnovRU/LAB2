﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SteganosGrapho
{
    class EncodeRawImg : ProcessImg
    {
        Bitmap image_raw;
        public override Bitmap get_image_raw() { return image_raw; }
        public override Bitmap processImage(Bitmap sourceImage,
        ref BackgroundWorker worker)
        {
            process_bytes = new ProcessBytes();
            image_raw = process_bytes.EncodeRawImage(sourceImage, ref worker);
            return image_raw;
        }
    }
}
